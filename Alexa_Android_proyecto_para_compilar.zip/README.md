# Alexa — proyecto Android inicial versión 0.2.0

Proyecto Android nativo para Samsung Galaxy A04e / Android 14.

## Funciones incluidas en este código
- Interfaz con botones grandes y accesibles.
- Reconocimiento de voz al tocar el botón (servicio de reconocimiento del dispositivo).
- Respuestas habladas con Android TextToSpeech en español argentino; la voz concreta depende de las voces instaladas y configuradas en el Samsung.
- Consulta de hora.
- Creación de alarma mediante la aplicación Reloj del teléfono; la persona debe confirmar en el Reloj.
- Búsqueda de información en Google.
- Apertura de cámara.
- Búsqueda de contactos con permiso y confirmación antes de abrir el marcador telefónico. La llamada no se realiza sin intervención de la persona.

## Generar APK desde GitHub
1. Crear un repositorio público o privado llamado MiAsistenteAndroid.
2. Subir todos los archivos y carpetas de este ZIP a la raíz del repositorio.
3. Ir a Actions y ejecutar el flujo "Compilar Mi Asistente".
4. Al finalizar, descargar el artefacto Mi-Asistente-APK.
5. Descomprimirlo y transferir app-debug.apk al Samsung.
6. Abrir el APK y autorizar la instalación desde esa fuente cuando Android lo solicite.

## Límites de esta versión
- No escucha permanentemente ni se activa con pantalla apagada. Android limita el acceso al micrófono en segundo plano; esto requiere arquitectura adicional, servicio visible, permisos y pruebas en el dispositivo. Para activación con pantalla bloqueada, configurar Google Assistant/Voice Match en el Samsung.
- No responde automáticamente llamadas entrantes.
- No envía WhatsApp ni mensajes.
- La cámara solo abre la app de cámara: no reconoce billetes, objetos ni documentos.
- No se debe usar esta versión para validar dinero, medicamentos ni emergencias.
- No hay una compilación APK verificada todavía; el workflow de GitHub debe ejecutarse para producirla.
