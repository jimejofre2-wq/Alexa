plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ar.com.miasistente"
    compileSdk = 35
    defaultConfig {
        applicationId = "ar.com.miasistente"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
}
