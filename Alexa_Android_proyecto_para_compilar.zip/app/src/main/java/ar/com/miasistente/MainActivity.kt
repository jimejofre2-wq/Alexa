package ar.com.miasistente

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private val requestAudio = 100
    private val requestContacts = 101
    private var pendingContactName: String? = null
    private var pendingAlarmHour = -1
    private var pendingAlarmMinute = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(26, 34, 26, 34)
            setBackgroundColor(0xFF102B27.toInt())
        }
        val title = TextView(this).apply {
            text = "Alexa"
            textSize = 32f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            contentDescription = "Alexa"
        }
        status = TextView(this).apply {
            text = "Hola. Tocá el botón y hablame."
            textSize = 21f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 28, 8, 28)
            contentDescription = text.toString()
            accessibilityLiveRegion = 1
        }
        val listen = Button(this).apply {
            text = "TOCÁ Y HABLÁ"
            textSize = 25f
            minHeight = 130
            contentDescription = "Tocar para hablar con Alexa"
            setOnClickListener { requestListening() }
        }
        val time = makeButton("DECIME LA HORA") { tellTime() }
        val alarm = makeButton("PONER UNA ALARMA") {
            answer("Tocá hablar y decime: poné una alarma a las siete.")
            requestListening()
        }
        val camera = makeButton("ABRIR CÁMARA") { openCamera() }
        val contacts = makeButton("LLAMAR A UN CONTACTO") {
            answer("Decime: llamá a, seguido del nombre de la persona.")
            requestListening()
        }
        val help = TextView(this).apply {
            text = "Podés decir: qué hora es, poné una alarma a las ocho, llamá a Ana, buscá información sobre Barreal, o abrí la cámara."
            textSize = 17f
            setTextColor(0xFFE0EEE9.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 20, 8, 12)
        }
        listOf(title, status, listen, time, alarm, contacts, camera, help).forEach {
            layout.addView(it, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = 12
            })
        }
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 19f
        minHeight = 64
        setOnClickListener { action() }
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "AR"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale("es", "ES")
            }
            // Android permite elegir voces instaladas desde Ajustes > Texto a voz.
            // No todos los motores informan el género de la voz de forma fiable.
        }
    }

    private fun answer(message: String) {
        runOnUiThread {
            status.text = message
            status.contentDescription = message
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "mia_${System.currentTimeMillis()}")
        }
    }

    private fun requestListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        startListening()
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Te escucho")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { startActivityForResult(intent, 10) }
        catch (_: Exception) { answer("No encuentro reconocimiento de voz. Revisá que Google esté instalado y actualizado.") }
    }

    @Deprecated("Compatibilidad con dispositivos Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == Activity.RESULT_OK) {
            val phrase = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (phrase.isNotBlank()) handleCommand(phrase.lowercase(Locale("es", "AR")))
        }
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("hora") -> tellTime()
            command.contains("alarma") || command.contains("despert") -> parseAlarm(command)
            command.contains("llamá") || command.contains("llama") || command.contains("llamar") -> handleCall(command)
            command.contains("buscar") || command.contains("buscá") || command.contains("google") || command.contains("información") -> searchGoogle(command)
            command.contains("cámara") || command.contains("camara") || command.contains("foto") -> openCamera()
            command.contains("repetí") || command.contains("repeti") -> answer("Decime qué necesitás y te escucho.")
            else -> answer("Todavía no tengo esa función. Podés pedirme la hora, una alarma, llamar a un contacto, buscar en Google o abrir la cámara.")
        }
    }

    private fun tellTime() {
        val now = SimpleDateFormat("HH:mm", Locale("es", "AR")).format(Date())
        answer("Son las $now")
    }

    private fun parseAlarm(command: String) {
        val match = Regex("""(?:a las|las)\s+(\d{1,2})(?::(\d{2}))?""").find(command)
        if (match == null) {
            answer("No entendí la hora. Por ejemplo, decime: poné una alarma a las siete.")
            return
        }
        val hour = match.groupValues[1].toIntOrNull() ?: -1
        val minute = match.groupValues[2].toIntOrNull() ?: 0
        if (hour !in 0..23 || minute !in 0..59) {
            answer("Esa hora no parece válida.")
            return
        }
        answer("Voy a abrir el reloj para confirmar una alarma a las ${hour.toString().padStart(2,'0')} y ${minute.toString().padStart(2,'0')}.")
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Alarma de Alexa")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        launchSafely(intent, "No pude abrir la aplicación de reloj.")
    }

    private fun handleCall(command: String) {
        val name = command.replace(Regex(".*?(llamá|llama|llamar)(\\s+por teléfono)?\\s+a?\\s*"), "").trim()
        if (name.isBlank()) {
            answer("Decime el nombre del contacto al que querés llamar.")
            return
        }
        pendingContactName = name
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), requestContacts)
        } else findAndConfirmContact(name)
    }

    private fun findAndConfirmContact(name: String) {
        val matches = mutableListOf<Pair<String, String>>()
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )
            cursor?.use {
                while (it.moveToNext() && matches.size < 5) {
                    val n = it.getString(0) ?: continue
                    val p = it.getString(1) ?: continue
                    if (matches.none { pair -> pair.second == p }) matches.add(n to p)
                }
            }
        } catch (_: SecurityException) { answer("No tengo permiso para consultar tus contactos."); return }
        if (matches.isEmpty()) {
            answer("No encontré a $name en tus contactos.")
            return
        }
        val options = matches.map { "${it.first}, ${it.second}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("¿A quién querés llamar?")
            .setItems(options) { _, which ->
                val chosen = matches[which]
                AlertDialog.Builder(this)
                    .setTitle("Confirmar llamada")
                    .setMessage("¿Querés llamar a ${chosen.first}? Se abrirá el teléfono para iniciar la llamada.")
                    .setNegativeButton("Cancelar") { _, _ -> answer("Llamada cancelada.") }
                    .setPositiveButton("Sí, llamar") { _, _ ->
                        answer("Abriendo el teléfono para llamar a ${chosen.first}.")
                        launchSafely(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(chosen.second)}")), "No pude abrir el teléfono.")
                    }.show()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun searchGoogle(command: String) {
        val query = command.replace(Regex(".*?(buscar|buscá|google|información sobre)"), "").trim()
        if (query.isBlank()) {
            answer("No entendí qué querés buscar. Volvé a tocar hablar y decime el tema.")
            return
        }
        answer("Voy a buscar $query en Google.")
        launchSafely(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))), "No pude abrir Google.")
    }

    private fun openCamera() {
        answer("Voy a abrir la cámara. Pedí ayuda si necesitás orientar el teléfono.")
        launchSafely(Intent(MediaStore.ACTION_IMAGE_CAPTURE), "No pude abrir la cámara.")
    }

    private fun launchSafely(intent: Intent, error: String) {
        try { startActivity(intent) } catch (_: Exception) { answer(error) }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        val granted = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            requestAudio -> if (granted) startListening() else answer("Necesito permiso para usar el micrófono cuando vos tocás hablar.")
            requestContacts -> if (granted) pendingContactName?.let { findAndConfirmContact(it) }
                else answer("Sin permiso no puedo buscar tus contactos.")
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
